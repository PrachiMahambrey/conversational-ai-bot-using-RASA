CHARACTER_LIMIT_MESSAGE = ("{field} is longer than {maxsize} characters, "
                           "it will be truncated when displayed.")
