"""
Provides Incremental version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update Incremental` to change this file.

from incremental import Version

__version__ = Version('Incremental', 17, 5, 0)
__all__ = ["__version__"]
