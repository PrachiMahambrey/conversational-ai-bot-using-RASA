from networkx.algorithms.coloring.greedy_coloring import *
__all__ = ['greedy_color']
