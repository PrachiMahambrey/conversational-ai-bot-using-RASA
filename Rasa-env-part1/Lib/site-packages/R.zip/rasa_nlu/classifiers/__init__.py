from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# How many intents are at max put into the output intent
# ranking, everything else will be cut off
INTENT_RANKING_LENGTH = 10
