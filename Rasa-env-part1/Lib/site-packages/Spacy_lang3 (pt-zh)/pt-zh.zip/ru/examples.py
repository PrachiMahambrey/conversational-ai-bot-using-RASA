# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ru.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple рассматривает возможность покупки стартапа из Соединенного Королевства за $1 млрд",
    "Автономные автомобили переносят страховую ответственность на производителя",
    "В Сан Франциско рассматривается возможность запрета роботов-курьеров, которые перемещаются по тротуару",
    "Лондон - большой город Соединенного Королевства"
]
