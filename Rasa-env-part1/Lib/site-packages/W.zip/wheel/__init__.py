# __variables__ with double-quoted values will be available in setup.py:
__version__ = "0.32.3"
